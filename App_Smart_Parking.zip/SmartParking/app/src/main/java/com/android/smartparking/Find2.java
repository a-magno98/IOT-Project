package com.android.smartparking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.ubidots.ApiClient;
import com.ubidots.Value;
import com.ubidots.Variable;

public class Find2 extends AppCompatActivity {

    private TextView nb_1;
    private TextView nb_2;
    private Button bntUpdate;
    private Button bntBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find2);
        nb_1 = findViewById(R.id.nb_1);
        nb_2 = findViewById(R.id.nb_2);
        bntUpdate = findViewById(R.id.bntUpdate);
        bntBack = findViewById(R.id.bntBack);
        find_parking();

        bntUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                find_parking();
            }
        });

        bntBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenu();
            }
        });
    }

    private void find_parking(){
        new ApiUbidots().execute();
    }

    private void openMenu(){
        Intent intent = new Intent(this, Menu.class);
        startActivity(intent);
    }

    public class ApiUbidots extends AsyncTask<Integer, Void, Double[]> {
        private final String API_KEY = "BBFF-01d82a0ed6e6c49afe9ccfbd5ae2f3a538f";
        private final String VARIABLE_ID = "60e46ee673efc32383b85822";
        private final String VARIABLE_ID2 = "60e46f3373efc32874745709";

        @Override
        protected Double[] doInBackground(Integer... params) {
            ApiClient apiClient = new ApiClient(API_KEY);
            Variable numb_slot_1 = apiClient.getVariable(VARIABLE_ID);
            Variable numb_slot_2 = apiClient.getVariable(VARIABLE_ID2);
            Value[] variableValues = numb_slot_1.getValues();
            Value[] variableValues2 = numb_slot_2.getValues();
            Double[] arr = new Double[2];
            arr[0]=variableValues[0].getValue();
            arr[1]=variableValues2[0].getValue();
            return arr;

        }

        @Override
        protected void onPostExecute(Double[] arr) {
            // Update your views here
            Integer nb1 = arr[0].intValue();
            Integer nb2 = arr[1].intValue();

            nb_1.setText(Integer.toString(nb1));
            nb_2.setText(Integer.toString(nb2));
        }
    }
}